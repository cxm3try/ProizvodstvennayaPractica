﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using shyrik.Classes;

namespace shyrik.Pages
{
    /// <summary>
    /// Логика взаимодействия для dannie.xaml
    /// </summary>
    public partial class dannie : Page
    {
        public dannie()
        {
            InitializeComponent();

            dtgrListZakazi.ItemsSource = ODBConnectHelper.entobj.Zakazi.ToList();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            FrmApp.frmobj.GoBack();
        }


        private void dtgrListZakazi_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
