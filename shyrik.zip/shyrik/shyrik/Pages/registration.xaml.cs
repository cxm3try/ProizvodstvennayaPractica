﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using shyrik.Classes;

namespace shyrik.Pages
{
    /// <summary>
    /// Логика взаимодействия для registration.xaml
    /// </summary>
    public partial class registration : Page
    {
        public registration()
        {
            InitializeComponent();
        }

        private void BtnCreate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var userObj = ODBConnectHelper.entobj.Zakazchiki.FirstOrDefault(x => x.Login.ToLower() == TxbLogin.Text.ToLower()
                && x.Password == TxbPassword.Text);
                if (userObj == null)
                {
                    Zakazchiki zakazchiki = new Zakazchiki
                    {
                        Login = TxbLogin.Text,
                        Password = TxbPassword.Text,
                        FIO = TxbFIO.Text,
                        Adres = TxbAdres.Text,
                        Phone = TxbPhone.Text

                    };
                    ODBConnectHelper.entobj.Zakazchiki.Add(zakazchiki);
                    ODBConnectHelper.entobj.SaveChanges();
                    FrmApp.frmobj.GoBack();
                }
                else
                    MessageBox.Show("Такой пользователь уже зарегистрирован!",
"Уведомление",
                   MessageBoxButton.OK,
                   MessageBoxImage.Information);
            }
            catch (Exception ex)
            {

                MessageBox.Show("Критический сбой в работе приложения:" + ex.Message.ToString(),
            "Уведомление",
                MessageBoxButton.OK,
                MessageBoxImage.Warning);

            }
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            FrmApp.frmobj.GoBack();
        }

       
    }
}
