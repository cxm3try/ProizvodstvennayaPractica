﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace shyrik.Classes
{
    class ODBConnectHelper
    {
        public static sheremetyevEntities2 entobj;
    }
}
